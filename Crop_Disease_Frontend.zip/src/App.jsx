import { useState } from "react";

const API_URL = "http://localhost:8080/api/disease";

export default function App() {
  const [crop, setCrop] = useState("");
  const [location, setLocation] = useState("");
  const [image, setImage] = useState(null);
  const [preview, setPreview] = useState("");
  const [result, setResult] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  function chooseImage(e) {
    const file = e.target.files?.[0];
    if (!file) return;
    setImage(file);
    setPreview(URL.createObjectURL(file));
    setResult(null);
    setError("");
  }

  async function detectDisease(e) {
    e.preventDefault();
    if (!crop || !image) {
      setError("Please select a crop and upload a leaf image.");
      return;
    }

    setLoading(true);
    setError("");
    setResult(null);

    const form = new FormData();
    form.append("image", image);
    form.append("cropType", crop);
    form.append("location", location);

    try {
      const response = await fetch(`${API_URL}/predict`, {
        method: "POST",
        body: form
      });
      const data = await response.json();
      if (!response.ok) throw new Error(data.message || "Prediction failed.");
      setResult(data);
    } catch (err) {
      // Demo fallback when Spring Boot is not running
      setResult({
        status: crop === "Tomato" || crop === "Potato" ? "DISEASE DETECTED" : "HEALTHY",
        confidence: crop === "Tomato" ? 91.5 : 93.2,
        diagnosis: crop === "Tomato"
          ? "Possible Early Blight detected in the demonstration model."
          : "No major disease pattern detected by the demonstration model.",
        recommendedAction: "Monitor the crop regularly and consult a local agriculture expert before applying treatment."
      });
      setError("Demo result shown. Connect Spring Boot at localhost:8080 for the real API.");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="page">
      <header className="hero">
        <div className="nav">
          <div className="brand">🌿 AgriCare AI</div>
          <div className="navlinks">
            <a href="#detect">Detect</a>
            <a href="#how">How It Works</a>
            <a href="#about">About</a>
          </div>
        </div>

        <div className="hero-content">
          <div>
            <span className="tag">SMART FARMING SOLUTION</span>
            <h1>Crop Disease<br/><span>Detection System</span></h1>
            <p>Upload a crop or leaf image and get a quick disease status, confidence, diagnosis and recommended next action.</p>
            <a className="hero-btn" href="#detect">Start Detection →</a>
          </div>
          <div className="hero-art">
            <div className="sun"></div>
            <div className="leaf-art">🌱</div>
            <div className="field"></div>
          </div>
        </div>
      </header>

      <main>
        <section id="detect" className="detect-section">
          <div className="section-heading">
            <span>01</span>
            <div><h2>Analyze Your Crop</h2><p>Enter crop details and upload a clear leaf image.</p></div>
          </div>

          <form className="detect-card" onSubmit={detectDisease}>
            <div className="form-area">
              <label>Crop Type *</label>
              <select value={crop} onChange={e => setCrop(e.target.value)}>
                <option value="">Choose crop</option>
                <option>Tomato</option>
                <option>Rice</option>
                <option>Potato</option>
                <option>Wheat</option>
                <option>Other</option>
              </select>

              <label>Location</label>
              <input value={location} onChange={e => setLocation(e.target.value)} placeholder="Example: Tirupati, Andhra Pradesh" />

              <label>Crop / Leaf Image *</label>
              <label className="upload">
                <input type="file" accept="image/*" onChange={chooseImage}/>
                <span className="upload-icon">📷</span>
                <strong>Click to upload image</strong>
                <small>PNG, JPG or JPEG</small>
              </label>

              <button className="detect-btn" disabled={loading}>
                {loading ? "Analyzing..." : "🔍 Detect Disease"}
              </button>
              {error && <div className="notice">{error}</div>}
            </div>

            <div className="preview-area">
              {preview ? <img src={preview} alt="Selected leaf" /> : (
                <div className="empty-preview">
                  <div>🌿</div>
                  <strong>Image Preview</strong>
                  <span>Your uploaded crop image will appear here.</span>
                </div>
              )}
            </div>
          </form>
        </section>

        {result && (
          <section className="result-card">
            <div className={result.status === "HEALTHY" ? "result-icon healthy" : "result-icon disease"}>
              {result.status === "HEALTHY" ? "✓" : "!"}
            </div>
            <div className="result-main">
              <span className="result-label">PREDICTION RESULT</span>
              <h2>{result.status}</h2>
              <div className="confidence">Confidence <b>{result.confidence}%</b></div>
              <div className="progress"><div style={{width: `${result.confidence}%`}}></div></div>
              <div className="result-grid">
                <div><h3>Diagnosis</h3><p>{result.diagnosis}</p></div>
                <div><h3>Recommended Next Action</h3><p>{result.recommendedAction}</p></div>
              </div>
            </div>
          </section>
        )}

        <section id="how" className="how">
          <div className="section-heading">
            <span>02</span>
            <div><h2>How It Works</h2><p>Simple flow from image upload to useful guidance.</p></div>
          </div>
          <div className="steps">
            <div><b>01</b><h3>Upload</h3><p>Farmer uploads a crop or leaf image.</p></div>
            <div><b>02</b><h3>Process</h3><p>React sends the image to Spring Boot REST API.</p></div>
            <div><b>03</b><h3>Predict</h3><p>Prediction service returns disease status and confidence.</p></div>
            <div><b>04</b><h3>Guide</h3><p>User receives diagnosis and recommended action.</p></div>
          </div>
        </section>

        <section id="about" className="tech">
          <h2>Technology Used</h2>
          <div className="tech-grid">
            <div>⚛️ <b>React</b><span>Frontend UI</span></div>
            <div>☕ <b>Java 17</b><span>Backend</span></div>
            <div>🚀 <b>Spring Boot</b><span>REST API</span></div>
            <div>🗄️ <b>MySQL</b><span>Database</span></div>
            <div>🔗 <b>JPA / Hibernate</b><span>Persistence</span></div>
          </div>
        </section>
      </main>

      <footer>🌱 AgriCare AI • Crop Disease Detection Project</footer>
    </div>
  );
}
